CLOUD FORENSICS MINI-LAB — EVIDENCE PACKAGE
============================================

Source account : AWS account 123456789012  (Acme Corp)
Exported by    : IR team, on-call engagement #2026-0514
Time zone      : all timestamps are UTC

FILES
-----
  s3_access.log    S3 server access logs (data plane: object GET/PUT/HEAD).
                   Space-delimited. Note the request timestamp is bracketed and
                   contains a space: [13/May/2026:09:14:22 +0000] — it occupies
                   TWO whitespace fields, so the source IP is field 5 with awk's
                   default splitting.

  cloudtrail.json  CloudTrail management + IAM events (control plane: ListBuckets,
                   GetBucketAcl/Policy, CreateAccessKey, ConsoleLogin, etc.).
                   JSON, under the top-level "Records" array.

KNOWN-GOOD BASELINE  (established by IT, treat as trusted)
----------------------------------------------------------
  * All legitimate employee and service API access egresses through the
    corporate network:   198.51.100.0/24
  * The service account "svc-backup-dev" runs a nightly backup job that writes
    ONLY to the bucket "acme-backups".
  * Normal business activity occurs roughly 07:00-19:00 UTC.

YOUR TASK
---------
  Analyse the two logs and recover the requested findings (flags). Complete
  your forensic report as you go — you will need it for a short assessment
  quiz at the end of the lab. Everything is solvable with grep / awk / sort /
  uniq / jq — no internet access required.

USEFUL COMMANDS
---------------
  View a single log line to check field positions:
    head -1 s3_access.log

  Extract a specific field from every line, deduplicated:
    awk '{print $N}' s3_access.log | sort -u

  Filter lines matching (or not matching) a pattern:
    grep 'PATTERN' s3_access.log
    grep -v 'PATTERN' s3_access.log
    # PATTERN = whatever you're searching for at this step, e.g. an IP
    # address, a username, an IP range prefix (^198\.51\.100\.), etc.

  Count occurrences of each distinct value:
    awk '{print $N}' s3_access.log | sort | uniq -c

  Inspect the structure of the CloudTrail JSON:
    jq '.Records[0]' cloudtrail.json

  Filter CloudTrail records by field value and extract values as
  tab-separated output:
    jq -r '.Records[] | select(.FIELD=="VALUE") | [.fieldA, .fieldB] | @tsv' cloudtrail.json
