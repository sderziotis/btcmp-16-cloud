CLOUD FORENSICS MINI-LAB — EVIDENCE PACKAGE
============================================

Source account : AWS account 123456789012  (Acme Corp)
Exported by    : IR team, on-call engagement #2026-0514
Time zone      : all timestamps are UTC

FILES
-----
  s3_access.log    S3 server access logs (data plane: object GET/PUT/HEAD).
                   Space-delimited. Note the request timestamp is bracketed and
                   contains a space: [13/May/2026:09:14:22 +0000] — it occupies
                   TWO whitespace fields, so the source IP is field 5 with awk's
                   default splitting.

  cloudtrail.json  CloudTrail management + IAM events (control plane: ListBuckets,
                   GetBucketAcl/Policy, CreateAccessKey, ConsoleLogin, etc.).
                   JSON, under the top-level "Records" array.

KNOWN-GOOD BASELINE  (established by IT, treat as trusted)
----------------------------------------------------------
  * All legitimate employee and service API access egresses through the
    corporate network:   198.51.100.0/24
  * The service account "svc-backup-dev" runs a nightly backup job that writes
    ONLY to the bucket "acme-backups".
  * Normal business activity occurs roughly 07:00-19:00 UTC.

YOUR TASK
---------
  Analyse the two logs, recover the requested findings (flags), and write a
  short forensic summary of the incident. Everything is solvable with
  grep / awk / sort / uniq / jq — no internet access required.
